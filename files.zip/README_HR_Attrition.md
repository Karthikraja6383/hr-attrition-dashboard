# 👥 HR Attrition Analytics Dashboard

> A predictive analytics solution to identify key drivers of employee attrition and enable proactive HR retention strategies.

---

## 📌 Project Overview

Employee attrition is one of the most costly challenges organizations face. This project builds an end-to-end analytics pipeline that identifies **why employees leave** and **who is most at risk** — empowering HR teams to act before it's too late.

The solution combines machine learning classification models with rich visualizations, giving HR leadership clear, actionable insights backed by data.

---

## 📊 Dataset Summary

| Attribute | Value |
|---|---|
| Total Employees | 500 |
| Features | Age, Department, Monthly Income, Job Satisfaction, Years at Company |
| Target | Attrition (Yes / No) |
| Missing Values | None |

---

## 📈 Key Results

| Metric | Value |
|---|---|
| Overall Attrition Rate | **31.8%** |
| Employees Retained | 341 |
| Employees Left | 159 |
| Avg Age | 41.3 years |
| Avg Monthly Income | ₹68,448 |
| Avg Job Satisfaction | 2.48 / 4 |
| Avg Tenure | 9.2 years |

---

## 🏢 Attrition by Department

| Department | Attrition Count |
|---|---|
| HR | 43 |
| Sales | 43 |
| IT | 39 |
| Finance | 34 |

> HR and Sales have the highest attrition — indicating potential issues with workload, compensation, or culture in these departments.

---

## 🤖 ML Model Performance

| Model | Accuracy |
|---|---|
| **Logistic Regression** | **67.0%** ✅ Best |
| Decision Tree | 63.0% |
| Random Forest | 57.0% |

> Logistic Regression was selected as the final model based on highest accuracy and interpretability.

---

## 🔑 Feature Importance (Random Forest)

| Feature | Importance |
|---|---|
| Monthly Income | 34.3% |
| Age | 24.9% |
| Years at Company | 22.3% |
| Job Satisfaction | 9.6% |
| Department | 8.9% |

> Monthly Income is the strongest driver of attrition, followed by Age and Tenure.

---

## 📉 Visualizations

| Chart | Description |
|---|---|
| `01_attrition_distribution.png` | Overall Yes vs No attrition count |
| `02_attrition_by_department.png` | Attrition breakdown across departments |
| `03_age_distribution.png` | Age histogram split by attrition |
| `04_income_tenure_by_attrition.png` | Boxplots for income and tenure |
| `05_model_comparison.png` | Model accuracy comparison bar chart |
| `06_feature_importance.png` | Random Forest feature importance |

---

## 🔍 Key Insights

- Nearly **1 in 3 employees** left the organization (31.8% attrition rate)
- **HR and Sales** departments face the highest attrition pressure
- **Monthly Income** is the single strongest predictor of attrition
- Employees with **lower tenure** are at higher risk of leaving
- **Job Satisfaction** plays a moderate but notable role in attrition

---

## ✅ Recommendations

1. **Review compensation** structures in HR and Sales departments
2. **Focus retention programs** on employees with 0–3 years of tenure
3. **Monitor low satisfaction scores** and act proactively
4. Conduct **regular stay interviews** for mid-career employees (35–45 age group)

---

## 🛠️ Tech Stack

![Python](https://img.shields.io/badge/Python-3776AB?style=flat-square&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=flat-square&logo=pandas&logoColor=white)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-F7931E?style=flat-square&logo=scikit-learn&logoColor=white)
![Seaborn](https://img.shields.io/badge/Seaborn-4c72b0?style=flat-square)
![Matplotlib](https://img.shields.io/badge/Matplotlib-11557c?style=flat-square)

---

## 📁 Project Structure

```
hr-attrition-dashboard/
│
├── HR_Attrition.csv               ← Dataset
├── HR_Attrition_Full.ipynb        ← Full analysis notebook
│
└── outputs/
    ├── 01_attrition_distribution.png
    ├── 02_attrition_by_department.png
    ├── 03_age_distribution.png
    ├── 04_income_tenure_by_attrition.png
    ├── 05_model_comparison.png
    └── 06_feature_importance.png
```

---

## 🚀 How to Run

```bash
# Clone the repository
git clone https://github.com/Karthikraja6383/hr-attrition-dashboard.git
cd hr-attrition-dashboard

# Install dependencies
pip install pandas numpy seaborn matplotlib scikit-learn

# Launch the notebook
jupyter notebook HR_Attrition_Full.ipynb
```

---

## 📬 Connect

[![GitHub](https://img.shields.io/badge/GitHub-Karthikraja6383-181717?style=flat-square&logo=github)](https://github.com/Karthikraja6383)
